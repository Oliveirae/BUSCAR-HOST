
PASO 1 no script:

[ Opção 1 ]: Para colar o domínio/host e buscar subdomínio do site

host: Quando aparecer esta opção, digite ou cole o site/url

exemplo: google.com

Recomendo não usar http, https, www

[ Opção 2 ]: Mostrar status

Mostrando status dos hosts: Aqui na opção 2 ele mostrará todo o status dos hosts que
estão salvos na opção 3 [A opção 2 só funciona se você salvar hosts na opção 3! Use a 1 para achar hosts, copie e salve na opção 3, daí use a 2 para checar os status!]

PASO 2:

[ Opcion 3 ]: Guardar hosts

1) Cole os hosts para obter o status

2) Lembre-se de clicar CTRL + C para salvar e sair

3) ctrl + c é para salvar os hosts colados e depois voltar para iniciar o script
real-host.sh e especifique a opção 2 MOSTRAR STATUS


Pressione ENTER para voltar ao menu inicial...
